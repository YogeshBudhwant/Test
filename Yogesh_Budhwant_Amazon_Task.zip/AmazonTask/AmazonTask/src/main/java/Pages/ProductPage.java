package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProductPage {

	
	 WebDriver driver;

		public ProductPage(WebDriver driver) {
		       this.driver = driver;
		       PageFactory.initElements(driver, this);
		}
		
		@FindBy(xpath ="//img[@data-image-index='1']")
		private WebElement selectIphone;
		

		@FindBy(xpath ="(//span[@class='a-price-whole'])[1]")
		private WebElement iphonePrice;
		
		@FindBy(xpath ="(//button[text()='Add to cart'])[1]")
		private WebElement selectAddToCart;
		

		@FindBy(xpath ="//div[@id='ewc-compact-actions-container']//span[@class='a-button-inner']//a[contains(text(),'Go to Cart')]")
		private WebElement selectGoToCart;
		
		public void clickOnSelectedIphone() {
			selectIphone.click();
		}
		
		public String getIphonePrice() {
			return iphonePrice.getText();
		}
		
		public void clickOnAddToCart() {
			selectAddToCart.click();
		}
		
		public AddToCartPage clickOnGoToCart() {
			selectGoToCart.click();
			return new AddToCartPage(driver);
		}
}
